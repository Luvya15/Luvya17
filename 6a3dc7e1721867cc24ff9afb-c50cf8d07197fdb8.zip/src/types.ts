export interface ServiceIntegrator {
  id: string;
  name: string;
  version: string;
  icon: string;
  color: string;
  capabilities: string[];
  protocol: 'MCP Gateway' | 'Direct Connect';
  healthScore: number;
  authStatus: 'AUTHORIZED' | 'EXPIRED' | 'PENDING';
  lastSync: string;
  latencyTarget?: string;
  rotationInfo?: string;
}

export interface QueueItem {
  id: string;
  timestamp: string;
  modelNode: string;
  riskFactor: 'Data Leakage?' | 'Tone Violation' | 'Protocol Mismatch' | 'Prompt Injection' | 'High Return Rate';
  riskSeverity: 'critical' | 'moderate' | 'low';
  ambiguityScore: number;
  status: 'Awaiting Review' | 'Being Handled' | 'Resolved' | 'Flagged';
  assignedTo?: string;
  details?: string;
}

export interface SystemMetrics {
  cpuLoad: number;
  cpuTemp: number;
  availableStorage: number;
  throttledNodes: number;
  systemHealth: number;
  blockedThreats24h: number;
}

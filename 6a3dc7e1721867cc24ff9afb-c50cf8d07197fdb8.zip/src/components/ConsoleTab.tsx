import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface ConsoleTabProps {
  policyElasticity: number;
  setPolicyElasticity: (val: number) => void;
  autoAdjudication: boolean;
  setAutoAdjudication: (val: boolean) => void;
  onNavigateToTrace: () => void;
}

export default function ConsoleTab({
  policyElasticity,
  setPolicyElasticity,
  autoAdjudication,
  setAutoAdjudication,
  onNavigateToTrace,
}: ConsoleTabProps) {
  const [copied, setCopied] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [tempElasticity, setTempElasticity] = useState(policyElasticity);
  const [tempAuto, setTempAuto] = useState(autoAdjudication);
  
  // Simulated stats for sub-agents that users can interactively test/bump
  const [fraudAnomalies, setFraudAnomalies] = useState(14);
  const [logisticsLoad, setLogisticsLoad] = useState(68);

  const systemPromptText = `# ROLE
You are the "Returns Sentinel," a high-precision logic engine for e-commerce reverse logistics. 

# MANDATE
Your primary objective is to evaluate incoming return requests against dynamic business guardrails. 
You must synthesize data from the Fraud Specialist and Logistics Coordinator to issue a 
FINAL_DISPOSITION: [APPROVE | FLAG | DENY].

# PROTOCOL
1. Verify customer historical return-rate vs. peer benchmarks.
2. Cross-reference SKU fragility with available regional warehouse capacity.
3. If risk score > 0.75, escalate to Human-in-the-loop.`;

  const handleCopy = () => {
    navigator.clipboard.writeText(systemPromptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const saveConfig = () => {
    setPolicyElasticity(tempElasticity);
    setAutoAdjudication(tempAuto);
    setShowConfigModal(false);
  };

  return (
    <div className="space-y-xl" id="console-tab-container">
      {/* Hero Section: Agent Overview */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-lg items-start">
        <div className="lg:col-span-5 space-y-md">
          <div className="flex items-center gap-sm">
            <span className="material-symbols-outlined text-primary text-xl">shield_with_heart</span>
            <span className="font-headline text-xs font-semibold uppercase tracking-widest text-primary">Master Agent</span>
          </div>
          <h2 className="font-headline text-headline-xl text-[#e1e2ec]">Returns Sentinel</h2>
          <p className="font-sans text-body-lg text-on-surface-variant leading-relaxed">
            An autonomous orchestration layer designed to govern the entire lifecycle of reverse logistics, ensuring policy compliance while optimizing for customer lifetime value.
          </p>
          
          <div className="flex flex-wrap gap-sm pt-2">
            <span className="px-3 py-1 rounded-full glass-panel text-on-surface text-xs font-medium border-emerald-500/30 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Active
            </span>
            <span className="px-3 py-1 rounded-full glass-panel text-on-surface text-xs font-medium border-primary/30">
              v4.2.0-stable
            </span>
          </div>

          {/* Interactive Quick Metrics block */}
          <div className="grid grid-cols-2 gap-md pt-4">
            <div className="glass-panel p-md rounded-xl border-l-2 border-primary/40">
              <div className="text-[10px] text-on-surface-variant uppercase tracking-wider">Processed Today</div>
              <div className="text-2xl font-semibold mt-1">4,812</div>
              <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
                <span className="material-symbols-outlined text-xs">trending_up</span> +12.4% vs yesterday
              </div>
            </div>
            <div className="glass-panel p-md rounded-xl border-l-2 border-tertiary/40">
              <div className="text-[10px] text-on-surface-variant uppercase tracking-wider">Avg Resolution Time</div>
              <div className="text-2xl font-semibold mt-1">1.8s</div>
              <div className="text-[10px] text-on-surface-variant italic mt-1">
                Fully automated flow
              </div>
            </div>
          </div>
        </div>

        {/* Terminal: System Prompt */}
        <div className="lg:col-span-7">
          <div className="glass-panel rounded-xl overflow-hidden shadow-2xl border border-outline-variant/30">
            <div className="bg-surface-container-high px-md py-sm border-b border-outline-variant/20 flex justify-between items-center">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-error/40"></div>
                <div className="w-3 h-3 rounded-full bg-tertiary/40"></div>
                <div className="w-3 h-3 rounded-full bg-primary/40"></div>
              </div>
              <span className="font-mono text-xs text-on-surface-variant">system_prompt.md</span>
              <button 
                id="copy-prompt-btn"
                onClick={handleCopy} 
                className="p-1 hover:bg-surface-container-highest rounded text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1"
                title="Copy prompt file to clipboard"
              >
                <span className="material-symbols-outlined text-base">
                  {copied ? 'check' : 'content_copy'}
                </span>
                <span className="text-[11px] font-mono">{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <div className="p-lg terminal-block font-mono text-xs leading-relaxed max-h-[320px] overflow-y-auto">
              <pre className="text-primary/90 whitespace-pre-wrap">
                <span className="text-on-surface-variant font-bold"># ROLE</span>{"\n"}
                You are the "Returns Sentinel," a high-precision logic engine for e-commerce reverse logistics. {"\n"}{"\n"}
                <span className="text-on-surface-variant font-bold"># MANDATE</span>{"\n"}
                Your primary objective is to evaluate incoming return requests against dynamic business guardrails.{"\n"}
                You must synthesize data from the Fraud Specialist and Logistics Coordinator to issue a{"\n"}
                <span className="text-white bg-primary-container/20 px-1 rounded">FINAL_DISPOSITION: [APPROVE | FLAG | DENY]</span>.{"\n"}{"\n"}
                <span className="text-on-surface-variant font-bold"># PROTOCOL</span>{"\n"}
                1. Verify customer historical return-rate vs. peer benchmarks.{"\n"}
                2. Cross-reference SKU fragility with available regional warehouse capacity.{"\n"}
                3. If risk score &gt; 0.75, escalate to Human-in-the-loop.
              </pre>
            </div>
          </div>
        </div>
      </section>

      {/* Sub-Agents Grid */}
      <section className="space-y-lg">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h3 className="font-headline text-headline-lg text-[#e1e2ec]">Sub-Agent Ecosystem</h3>
            <p className="font-sans text-body-md text-on-surface-variant">Modular capabilities delegated to specialized sub-routines.</p>
          </div>
          <div className="hidden sm:block h-px flex-grow mx-lg mb-2 border-t border-outline-variant/20"></div>
          <button 
            onClick={onNavigateToTrace}
            className="text-primary hover:text-primary-container font-headline text-xs font-semibold tracking-wider uppercase flex items-center gap-1.5 self-start sm:self-auto hover:underline"
          >
            <span>Monitor Workflow Loop</span>
            <span className="material-symbols-outlined text-sm">arrow_forward</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
          {/* Fraud Specialist Card */}
          <div className="glass-panel p-lg rounded-xl glow-border transition-all flex flex-col justify-between gap-md group border border-outline-variant/15 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-error/5 to-transparent pointer-events-none"></div>
            
            <div className="space-y-md">
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-error/10 rounded-lg border border-error/20">
                  <span className="material-symbols-outlined text-error text-3xl">policy</span>
                </div>
                <div className="text-right">
                  <div className="text-error font-headline text-[10px] font-semibold uppercase tracking-wider">Compliance Level</div>
                  <div className="font-headline text-lg font-bold text-on-surface mt-0.5">High-Risk</div>
                </div>
              </div>
              
              <div>
                <h4 className="font-headline text-xl font-semibold group-hover:text-primary transition-colors">Fraud Specialist</h4>
                <p className="font-sans text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                  Monitors pattern anomalies in return frequency, item switching, and "wardrobing" behaviors in real-time.
                </p>
              </div>

              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Pattern Recognition</span>
                  <span className="text-primary font-semibold">99.8%</span>
                </div>
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Response Latency</span>
                  <span className="text-primary font-semibold">45ms</span>
                </div>
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Active Flagged Anomalies</span>
                  <span className="text-error font-semibold flex items-center gap-1">
                    {fraudAnomalies}
                    <button 
                      onClick={() => setFraudAnomalies(prev => prev + 1)}
                      className="text-[10px] bg-error/10 hover:bg-error/20 border border-error/30 rounded px-1 text-error active:scale-90"
                      title="Simulate fraud anomaly event"
                    >
                      + Simulate
                    </button>
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-4">
              <span className="bg-surface-container px-2.5 py-1 rounded text-[10px] font-bold text-on-surface-variant uppercase tracking-widest border border-outline-variant/30">
                Identity Verification
              </span>
              <span className="bg-surface-container px-2.5 py-1 rounded text-[10px] font-bold text-on-surface-variant uppercase tracking-widest border border-outline-variant/30">
                Behavioral Scoring
              </span>
            </div>
          </div>

          {/* Logistics Coordinator Card */}
          <div className="glass-panel p-lg rounded-xl glow-border transition-all flex flex-col justify-between gap-md group border border-outline-variant/15 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-primary/5 to-transparent pointer-events-none"></div>

            <div className="space-y-md">
              <div className="flex justify-between items-start">
                <div className="p-2.5 bg-primary/10 rounded-lg border border-primary/20">
                  <span className="material-symbols-outlined text-primary text-3xl">local_shipping</span>
                </div>
                <div className="text-right">
                  <div className="text-primary font-headline text-[10px] font-semibold uppercase tracking-wider">Routing Efficiency</div>
                  <div className="font-headline text-lg font-bold text-on-surface mt-0.5">94.2%</div>
                </div>
              </div>

              <div>
                <h4 className="font-headline text-xl font-semibold group-hover:text-primary transition-colors">Logistics Coordinator</h4>
                <p className="font-sans text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                  Optimizes return paths based on carbon footprint, warehouse labor availability, and regional carrier capacity.
                </p>
              </div>

              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Fleet Integration</span>
                  <span className="text-primary font-semibold">Connected</span>
                </div>
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Cost Optimization</span>
                  <span className="text-emerald-400 font-semibold">Enabled</span>
                </div>
                <div className="flex justify-between text-xs font-mono border-b border-outline-variant/10 pb-1.5">
                  <span className="text-on-surface-variant">Warehouse Load</span>
                  <span className="text-primary font-semibold flex items-center gap-1.5">
                    {logisticsLoad}% Capacity
                    <input 
                      type="range" 
                      min="30" 
                      max="100" 
                      value={logisticsLoad} 
                      onChange={(e) => setLogisticsLoad(Number(e.target.value))} 
                      className="w-16 accent-primary h-1 cursor-pointer bg-surface-container-highest rounded-lg"
                      title="Adjust warehouse load metric"
                    />
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-4">
              <span className="bg-surface-container px-2.5 py-1 rounded text-[10px] font-bold text-on-surface-variant uppercase tracking-widest border border-outline-variant/30">
                Dynamic Routing
              </span>
              <span className="bg-surface-container px-2.5 py-1 rounded text-[10px] font-bold text-on-surface-variant uppercase tracking-widest border border-outline-variant/30">
                LCA Analysis
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Capabilities Bento */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-lg">
        {/* Neural Decision Engine Block */}
        <div className="md:col-span-2 glass-panel p-lg rounded-xl relative overflow-hidden min-h-[220px] flex flex-col justify-between border border-outline-variant/15">
          {/* Animated network lines in background */}
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="gradient-line" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#f472b6" />
                </linearGradient>
              </defs>
              <line x1="10%" y1="20%" x2="40%" y2="80%" stroke="url(#gradient-line)" strokeWidth="1" strokeDasharray="5,5" />
              <line x1="40%" y1="80%" x2="80%" y2="30%" stroke="url(#gradient-line)" strokeWidth="1.5" />
              <line x1="80%" y1="30%" x2="90%" y2="90%" stroke="url(#gradient-line)" strokeWidth="0.8" />
              <circle cx="40%" cy="80%" r="4" fill="#6366f1" className="animate-pulse" />
              <circle cx="80%" cy="30%" r="3" fill="#f472b6" />
            </svg>
          </div>
          
          <div className="flex justify-between items-start z-10">
            <span className="px-2.5 py-1 bg-primary/10 rounded-lg text-primary text-[10px] font-mono tracking-wider font-semibold border border-primary/20">
              DECISION ENGINE ONLINE
            </span>
            <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse-dot"></span>
              <span>124 decisions/sec</span>
            </div>
          </div>

          <div className="relative z-10 h-full flex flex-col justify-end mt-8">
            <h5 className="font-headline text-xl font-bold text-on-surface">Neural Decision Engine</h5>
            <p className="font-sans text-body-sm text-on-surface-variant mt-1.5 max-w-prose leading-relaxed">
              Real-time processing of complex multi-vector return policies utilizing server-side Gemini decision nodes to adjudicate edge cases dynamically.
            </p>
          </div>
        </div>

        {/* Guardrail Card */}
        <div className="glass-panel p-lg rounded-xl border-l-4 border-tertiary flex flex-col justify-between border border-outline-variant/15">
          <div className="space-y-sm">
            <h5 className="font-headline text-xs font-semibold text-tertiary uppercase tracking-widest">Active Guardrail</h5>
            
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-md">
                <span className="material-symbols-outlined text-tertiary text-2xl">lock_open</span>
                <div>
                  <span className="font-sans text-xs text-on-surface-variant block">Policy Elasticity</span>
                  <span className="font-mono text-sm text-on-surface font-semibold">{policyElasticity}% Allowed</span>
                </div>
              </div>
              <div className="flex items-center gap-md">
                <span className="material-symbols-outlined text-tertiary text-2xl">gavel</span>
                <div>
                  <span className="font-sans text-xs text-on-surface-variant block">Auto-Adjudication</span>
                  <span className="font-mono text-sm text-on-surface font-semibold">
                    {autoAdjudication ? 'Strictly ON' : 'OFF (Manual Trigger)'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <button 
            onClick={() => setShowConfigModal(true)}
            className="w-full mt-6 py-2 bg-tertiary/10 border border-tertiary/30 text-tertiary font-headline text-xs font-semibold rounded hover:bg-tertiary hover:text-on-tertiary active:scale-[0.98] transition-all cursor-pointer"
          >
            Configure Rules
          </button>
        </div>
      </section>

      {/* Rules Config Modal */}
      <AnimatePresence>
        {showConfigModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-md rounded-2xl border border-outline-variant/40 overflow-hidden shadow-2xl bg-surface-container-low"
            >
              <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-tertiary">settings</span>
                  <h3 className="font-headline text-lg font-bold text-on-surface">Configure Guardrails</h3>
                </div>
                <button 
                  onClick={() => setShowConfigModal(false)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg space-y-md">
                {/* Elasticity range */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-on-surface-variant font-medium">Policy Elasticity</span>
                    <span className="text-tertiary font-mono font-bold">{tempElasticity}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="40" 
                    value={tempElasticity}
                    onChange={(e) => setTempElasticity(Number(e.target.value))}
                    className="w-full h-2 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-tertiary"
                  />
                  <p className="text-[11px] text-on-surface-variant italic leading-relaxed">
                    Specifies the allowed deviation margin from standard policy limits before triggering manual escalating paths.
                  </p>
                </div>

                {/* Auto adjudication switch */}
                <div className="flex items-center justify-between pt-2 border-t border-outline-variant/10">
                  <div className="flex flex-col pr-4">
                    <span className="text-xs font-semibold text-on-surface">Auto-Adjudication Engine</span>
                    <span className="text-[11px] text-on-surface-variant mt-0.5">
                      Allow Sentinel to auto-resolve verified complaints without human review queue triggers.
                    </span>
                  </div>
                  <button 
                    onClick={() => setTempAuto(!tempAuto)}
                    className={`w-12 h-6 rounded-full p-1 transition-colors relative duration-200 ${tempAuto ? 'bg-tertiary' : 'bg-surface-container-highest border border-outline-variant'}`}
                  >
                    <div className={`w-4 h-4 bg-surface rounded-full transition-transform duration-200 ${tempAuto ? 'translate-x-6' : 'translate-x-0'}`} />
                  </button>
                </div>
              </div>

              <div className="bg-surface-container-high/50 px-lg py-md border-t border-outline-variant/20 flex justify-end gap-3">
                <button 
                  onClick={() => setShowConfigModal(false)}
                  className="px-4 py-2 border border-outline-variant hover:bg-surface-container-highest rounded-lg text-xs font-headline font-semibold text-on-surface"
                >
                  Cancel
                </button>
                <button 
                  onClick={saveConfig}
                  className="px-4 py-2 bg-tertiary text-on-tertiary hover:opacity-90 rounded-lg text-xs font-headline font-semibold"
                >
                  Save Settings
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React, { useState } from 'react';
import { ServiceIntegrator } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ToolboxTabProps {
  integrators: ServiceIntegrator[];
  setIntegrators: React.Dispatch<React.SetStateAction<ServiceIntegrator[]>>;
  keyRotation: boolean;
  setKeyRotation: (val: boolean) => void;
  piiMasking: boolean;
  setPiiMasking: (val: boolean) => void;
  contextIsolation: boolean;
  setContextIsolation: (val: boolean) => void;
}

export default function ToolboxTab({
  integrators,
  setIntegrators,
  keyRotation,
  setKeyRotation,
  piiMasking,
  setPiiMasking,
  contextIsolation,
  setContextIsolation,
}: ToolboxTabProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newApiName, setNewApiName] = useState('');
  const [newApiCapability, setNewApiCapability] = useState('Read Orders');
  const [newApiProtocol, setNewApiProtocol] = useState<'MCP Gateway' | 'Direct Connect'>('MCP Gateway');
  const [newApiHealth, setNewApiHealth] = useState(95);

  const [simulatedPulse, setSimulatedPulse] = useState<'user' | 'gateway' | 'model' | 'external' | null>(null);

  const handleReauth = (id: string) => {
    setIntegrators(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          authStatus: 'AUTHORIZED',
          healthScore: 100,
          latencyTarget: '100% Operational'
        };
      }
      return item;
    }));
  };

  const handleProvision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApiName) return;

    const newIntegrator: ServiceIntegrator = {
      id: Math.random().toString(),
      name: newApiName,
      version: 'v1.0.0-Beta',
      icon: newApiName.toLowerCase().includes('payment') || newApiName.toLowerCase().includes('stripe') ? 'payments' : 'dns',
      color: '#4D148C',
      capabilities: [newApiCapability],
      protocol: newApiProtocol,
      healthScore: newApiHealth,
      authStatus: 'AUTHORIZED',
      lastSync: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
      latencyTarget: `${newApiHealth}% Latency Target`
    };

    setIntegrators(prev => [...prev, newIntegrator]);
    setNewApiName('');
    setShowAddModal(false);
  };

  const handleTriggerDataPulse = (node: 'user' | 'gateway' | 'model' | 'external') => {
    setSimulatedPulse(node);
    setTimeout(() => setSimulatedPulse(null), 1500);
  };

  const healthyCount = integrators.filter(item => item.authStatus === 'AUTHORIZED' && item.healthScore > 80).length;

  return (
    <div className="space-y-xl" id="toolbox-tab-container">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="font-headline text-headline-lg text-[#e1e2ec] mb-1">Tooling &amp; Integration</h2>
          <p className="text-on-surface-variant font-sans text-body-lg">
            Manage external service pipelines and Model Context Protocol (MCP) bridges.
          </p>
        </div>
        <div className="text-right text-xs text-on-surface-variant font-mono">
          System Time: <span className="text-primary font-semibold">{new Date().toISOString().substring(11, 19)} UTC</span>
        </div>
      </div>

      {/* System Architecture Canvas Preview */}
      <div className="grid grid-cols-12 gap-lg">
        <div className="col-span-12 glass-panel rounded-xl p-lg relative overflow-hidden h-44 flex items-center justify-center border border-outline-variant/20 shadow-lg">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-on-secondary-container/5 pointer-events-none"></div>
          
          <div className="relative z-10 flex items-center gap-xl w-full max-w-lg justify-between px-md">
            <div className="flex flex-col items-center gap-sm">
              <div className="w-12 h-12 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center shadow-lg shadow-primary/10">
                <span className="material-symbols-outlined text-primary text-2xl">hub</span>
              </div>
              <span className="font-headline text-[10px] font-bold uppercase tracking-widest text-primary">Core Node</span>
            </div>

            <div className="flex-grow flex items-center relative">
              <div className="connection-line w-full"></div>
              {/* Animated processing beam */}
              <motion.div 
                animate={{ left: ['0%', '100%'] }}
                transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
                className="absolute -top-1 w-2.5 h-2.5 rounded-full bg-primary shadow-[0_0_8px_#adc6ff]"
              />
            </div>

            <div className="flex flex-col items-center gap-sm">
              <div className="w-12 h-12 rounded-lg bg-surface-container-highest border border-outline-variant flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-on-surface-variant text-2xl">dns</span>
              </div>
              <span className="font-headline text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">External APIs</span>
            </div>
          </div>
        </div>
      </div>

      {/* Data Grid: Services */}
      <div className="glass-panel rounded-xl overflow-hidden border border-outline-variant/15 shadow-xl">
        <div className="bg-surface-container-high/50 px-lg py-md flex items-center justify-between border-b border-outline-variant/20">
          <div className="flex items-center gap-sm">
            <span className="material-symbols-outlined text-primary">integration_instructions</span>
            <span className="font-headline text-xs font-semibold uppercase tracking-wider text-on-surface-variant">Active Service Map</span>
          </div>
          <button 
            id="provision-api-btn"
            onClick={() => setShowAddModal(true)}
            className="bg-primary hover:bg-primary/90 text-on-primary font-headline text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 transition-colors active:scale-95 cursor-pointer shadow-lg shadow-primary/10"
          >
            <span className="material-symbols-outlined text-base">add</span>
            Provision API
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="border-b border-outline-variant/15 font-headline text-[10px] text-on-surface-variant uppercase tracking-wider bg-surface-container-low/40">
                <th className="px-lg py-3.5 font-bold">Integrator Name</th>
                <th className="px-lg py-3.5 font-bold">Capability</th>
                <th className="px-lg py-3.5 font-bold">Protocol</th>
                <th className="px-lg py-3.5 font-bold">Health Score</th>
                <th className="px-lg py-3.5 font-bold">Auth Status</th>
                <th className="px-lg py-3.5 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="font-mono text-xs divide-y divide-outline-variant/10">
              {integrators.map((item) => (
                <tr key={item.id} className="hover:bg-primary/5 transition-colors group">
                  <td className="px-lg py-lg">
                    <div className="flex items-center gap-md">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center border transition-colors" style={{ backgroundColor: `${item.color}15`, borderColor: `${item.color}35` }}>
                        <span className="material-symbols-outlined text-xl" style={{ color: item.color }}>{item.icon}</span>
                      </div>
                      <div>
                        <div className="font-headline text-xs font-semibold text-on-surface group-hover:text-primary transition-colors">{item.name}</div>
                        <div className="text-[10px] text-on-surface-variant opacity-60 mt-0.5">{item.version}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-lg py-lg">
                    <div className="flex flex-wrap gap-1">
                      {item.capabilities.map((cap, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-secondary-container/30 text-secondary text-[10px] border border-outline-variant/20">
                          {cap}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-lg py-lg">
                    <div className="flex items-center gap-1.5 font-sans text-xs">
                      <span className={`material-symbols-outlined text-base ${item.protocol === 'MCP Gateway' ? 'text-primary' : 'text-on-surface-variant'}`}>
                        {item.protocol === 'MCP Gateway' ? 'bolt' : 'link'}
                      </span>
                      <span>{item.protocol}</span>
                    </div>
                  </td>
                  <td className="px-lg py-lg">
                    <div className="max-w-[140px]">
                      <div className="w-full bg-surface-container-highest h-1 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${item.healthScore > 90 ? 'bg-primary' : item.healthScore > 80 ? 'bg-tertiary' : 'bg-error'}`}
                          style={{ width: `${item.healthScore}%` }}
                        ></div>
                      </div>
                      <span className={`text-[10px] mt-1.5 block font-sans ${item.healthScore > 90 ? 'text-primary' : item.healthScore > 80 ? 'text-tertiary' : 'text-error'}`}>
                        {item.latencyTarget || `${item.healthScore}% Optimal`}
                      </span>
                    </div>
                  </td>
                  <td className="px-lg py-lg">
                    {item.authStatus === 'AUTHORIZED' ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-950/20 text-green-400 text-[10px] border border-green-500/20 font-sans font-semibold">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                        AUTHORIZED
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-error-container/30 text-error text-[10px] border border-error/20 font-sans font-semibold">
                        <span className="w-1.5 h-1.5 rounded-full bg-error"></span>
                        EXPIRED
                      </span>
                    )}
                  </td>
                  <td className="px-lg py-lg text-right">
                    {item.authStatus === 'EXPIRED' ? (
                      <button 
                        onClick={() => handleReauth(item.id)}
                        className="bg-error/15 text-error hover:bg-error hover:text-on-error transition-all px-3 py-1.5 rounded-lg text-[10px] font-bold font-headline uppercase cursor-pointer"
                      >
                        Re-Auth
                      </button>
                    ) : (
                      <button className="material-symbols-outlined text-on-surface-variant hover:text-primary transition-colors cursor-pointer p-1 rounded hover:bg-surface-container-highest">
                        settings
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Footer/Status */}
        <div className="bg-surface-container-low px-lg py-3 flex flex-col sm:flex-row justify-between items-center text-[10px] border-t border-outline-variant/20 text-on-surface-variant gap-2 font-mono">
          <div className="flex flex-wrap gap-md justify-center">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-400"></span> 
              {healthyCount}/{integrators.length} Services Healthy
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-primary"></span> 
              MCP Protocol: Active (v4.2)
            </span>
          </div>
          <div>Last sync: 2026-06-25 17:04:00 PST</div>
        </div>
      </div>

      {/* Bottom Grid: Flows and Security Guardrails */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
        {/* Data Flow Visualization */}
        <div className="glass-panel p-lg rounded-xl flex flex-col gap-md border border-outline-variant/15 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-sm">
              <span className="material-symbols-outlined text-primary">schema</span>
              <h3 className="font-headline text-xs font-semibold uppercase text-on-surface tracking-wider">Data Flow Visualization</h3>
            </div>
            <span className="text-[10px] text-on-surface-variant font-mono">Click nodes to simulate request triggers</span>
          </div>

          <div className="flex-grow min-h-[220px] border border-outline-variant/10 rounded-xl bg-surface-container-lowest/50 relative p-md flex flex-col justify-between overflow-hidden">
            <div className="flex justify-between z-10">
              <button 
                onClick={() => handleTriggerDataPulse('user')}
                className={`p-2.5 border rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${simulatedPulse === 'user' ? 'border-primary bg-primary/20 text-primary scale-105 shadow-[0_0_12px_rgba(77,142,255,0.3)]' : 'border-primary/20 bg-primary/5 text-primary hover:bg-primary/10'}`}
              >
                User Request
              </button>
              <button 
                onClick={() => handleTriggerDataPulse('gateway')}
                className={`p-2.5 border rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${simulatedPulse === 'gateway' ? 'border-secondary bg-secondary/25 text-on-secondary-container scale-105 shadow-[0_0_12px_rgba(183,200,225,0.3)]' : 'border-outline-variant/20 bg-surface-container text-on-surface-variant hover:bg-surface-container-high'}`}
              >
                Gateway Dispatch
              </button>
            </div>

            {/* Connection SVG with simulated moving pulses */}
            <div className="absolute inset-0 pointer-events-none opacity-40">
              <svg className="w-full h-full" viewBox="0 0 400 200" preserveAspectRatio="none">
                <path d="M70,40 C150,60 250,60 330,40" fill="transparent" stroke="#adc6ff" strokeDasharray="4 2" strokeWidth="1" />
                <path d="M70,160 C150,140 250,140 330,160" fill="transparent" stroke="#adc6ff" strokeDasharray="4 2" strokeWidth="1" />
                <path d="M350,60 L350,140" fill="transparent" stroke="#adc6ff" strokeDasharray="4 2" strokeWidth="1" />
                <path d="M50,60 L50,140" fill="transparent" stroke="#adc6ff" strokeDasharray="4 2" strokeWidth="1" />
                
                {simulatedPulse && (
                  <circle r="4" fill="#adc6ff" className="shadow-[0_0_8px_#adc6ff]">
                    <animateMotion dur="1s" repeatCount="1" path="M70,40 C150,60 250,60 330,40" fill="freeze" />
                  </circle>
                )}
              </svg>
            </div>

            <div className="flex justify-between z-10">
              <button 
                onClick={() => handleTriggerDataPulse('model')}
                className={`p-2.5 border rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${simulatedPulse === 'model' ? 'border-primary bg-primary/25 text-primary scale-105' : 'border-outline-variant/20 bg-surface-container text-on-surface-variant hover:bg-surface-container-high'}`}
              >
                Model Evaluation
              </button>
              <button 
                onClick={() => handleTriggerDataPulse('external')}
                className={`p-2.5 border rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${simulatedPulse === 'external' ? 'border-tertiary bg-tertiary/20 text-tertiary scale-105' : 'border-tertiary/20 bg-tertiary/5 text-tertiary hover:bg-tertiary/10'}`}
              >
                External Verification
              </button>
            </div>
          </div>
        </div>

        {/* API Security Guardrail */}
        <div className="glass-panel p-lg rounded-xl flex flex-col gap-md border border-outline-variant/15 shadow-md justify-between">
          <div className="space-y-sm">
            <div className="flex items-center gap-sm">
              <span className="material-symbols-outlined text-primary">security</span>
              <h3 className="font-headline text-xs font-semibold uppercase text-on-surface tracking-wider">API Security Guardrail</h3>
            </div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              Verify compliance configurations securing remote application connections against prompt injections and telemetry theft.
            </p>
          </div>

          <div className="space-y-3.5">
            {/* Toggle 1 */}
            <div className="flex items-center justify-between p-md bg-surface-container-high/40 rounded-xl border border-outline-variant/10">
              <div className="flex flex-col pr-4">
                <span className="font-headline text-xs font-semibold text-on-surface">Automatic Key Rotation</span>
                <span className="text-[10px] text-on-surface-variant mt-0.5">Cycles token keys every 30 days dynamically</span>
              </div>
              <button 
                onClick={() => setKeyRotation(!keyRotation)}
                className={`w-10 h-5 rounded-full p-0.5 transition-colors relative duration-200 ${keyRotation ? 'bg-primary' : 'bg-surface-container-highest'}`}
              >
                <div className={`w-4 h-4 bg-surface rounded-full transition-transform duration-200 ${keyRotation ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Toggle 2 */}
            <div className="flex items-center justify-between p-md bg-surface-container-high/40 rounded-xl border border-outline-variant/10">
              <div className="flex flex-col pr-4">
                <span className="font-headline text-xs font-semibold text-on-surface">PII Masking Protocol</span>
                <span className="text-[10px] text-on-surface-variant mt-0.5">Redacts custom e-commerce customer names in transit</span>
              </div>
              <button 
                onClick={() => setPiiMasking(!piiMasking)}
                className={`w-10 h-5 rounded-full p-0.5 transition-colors relative duration-200 ${piiMasking ? 'bg-primary' : 'bg-surface-container-highest'}`}
              >
                <div className={`w-4 h-4 bg-surface rounded-full transition-transform duration-200 ${piiMasking ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Toggle 3 */}
            <div className="flex items-center justify-between p-md bg-surface-container-high/40 rounded-xl border border-outline-variant/10">
              <div className="flex flex-col pr-4">
                <span className="font-headline text-xs font-semibold text-on-surface">Model Context Isolation</span>
                <span className="text-[10px] text-on-surface-variant mt-0.5">Prevents semantic leakage between specialized sub-agents</span>
              </div>
              <button 
                onClick={() => setContextIsolation(!contextIsolation)}
                className={`w-10 h-5 rounded-full p-0.5 transition-colors relative duration-200 ${contextIsolation ? 'bg-primary' : 'bg-surface-container-highest'}`}
              >
                <div className={`w-4 h-4 bg-surface rounded-full transition-transform duration-200 ${contextIsolation ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Provision API Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-md rounded-2xl border border-outline-variant/40 overflow-hidden shadow-2xl bg-surface-container-low"
            >
              <form onSubmit={handleProvision}>
                <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">add_box</span>
                    <h3 className="font-headline text-lg font-bold text-on-surface">Provision New API</h3>
                  </div>
                  <button 
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <div className="p-lg space-y-md">
                  {/* Name */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block">Integrator Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. PayPal Settlement API" 
                      value={newApiName}
                      onChange={(e) => setNewApiName(e.target.value)}
                      required
                      className="w-full bg-surface-container-highest border border-outline-variant/30 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-primary text-white"
                    />
                  </div>

                  {/* Capability */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block">Primary Capability</label>
                    <select 
                      value={newApiCapability}
                      onChange={(e) => setNewApiCapability(e.target.value)}
                      className="w-full bg-surface-container-highest border border-outline-variant/30 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-primary text-white"
                    >
                      <option value="Read Orders">Read Orders</option>
                      <option value="Refunds">Refunds</option>
                      <option value="Write Orders">Write Orders</option>
                      <option value="Fraud Score">Fraud Score</option>
                      <option value="Label Gen">Label Gen</option>
                      <option value="Address Verification">Address Verification</option>
                    </select>
                  </div>

                  {/* Protocol */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block">Connection Protocol</label>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 text-xs text-on-surface cursor-pointer">
                        <input 
                          type="radio" 
                          name="protocol" 
                          checked={newApiProtocol === 'MCP Gateway'}
                          onChange={() => setNewApiProtocol('MCP Gateway')}
                          className="accent-primary"
                        />
                        MCP Gateway
                      </label>
                      <label className="flex items-center gap-2 text-xs text-on-surface cursor-pointer">
                        <input 
                          type="radio" 
                          name="protocol" 
                          checked={newApiProtocol === 'Direct Connect'}
                          onChange={() => setNewApiProtocol('Direct Connect')}
                          className="accent-primary"
                        />
                        Direct Connect
                      </label>
                    </div>
                  </div>

                  {/* Health slider */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-on-surface-variant font-medium">Expected Health Target</span>
                      <span className="text-primary font-mono font-bold">{newApiHealth}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="60" 
                      max="100" 
                      value={newApiHealth}
                      onChange={(e) => setNewApiHealth(Number(e.target.value))}
                      className="w-full h-1.5 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>
                </div>

                <div className="bg-surface-container-high/50 px-lg py-md border-t border-outline-variant/20 flex justify-end gap-3">
                  <button 
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-outline-variant hover:bg-surface-container-highest rounded-lg text-xs font-headline font-semibold text-on-surface"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-2 bg-primary text-on-primary hover:opacity-90 rounded-lg text-xs font-headline font-semibold shadow-md"
                  >
                    Deploy pipeline
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

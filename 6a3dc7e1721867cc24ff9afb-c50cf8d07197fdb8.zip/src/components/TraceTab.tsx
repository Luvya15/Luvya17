import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ComplianceLineChart from './ComplianceLineChart';

interface TraceTabProps {
  complianceScore: number;
  setComplianceScore: React.Dispatch<React.SetStateAction<number>>;
  logisticsCapacity: number;
}

export default function TraceTab({
  complianceScore,
  setComplianceScore,
  logisticsCapacity,
}: TraceTabProps) {
  const [showLogs, setShowLogs] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [hitlResolved, setHitlResolved] = useState(false);
  const [hitlResolution, setHitlResolution] = useState<'APPROVED' | 'FLAGGED' | 'DENIED' | null>(null);
  
  // Real logs state that is appended to when users interact
  const [logs, setLogs] = useState<string[]>([
    "[14:02:11] INGESTION_NODE: Ingested request RTN-8821 from webhook_aws",
    "[14:02:12] POLICY_CHECK: Verified standard 30 day policy tier: Gold VIP customer",
    "[14:02:14] ROUTING_ENGINE: Pre-calculated optimal carrier path: Carrier_B_Express",
    "[14:02:15] FRAUD_AUDITOR: Scanning return patterns... anomaly score 0.742 exceeds threshold 0.7",
    "[14:02:16] MASTER_AGENT: HITL trigger generated: Escolated execution to Architect Console"
  ]);

  const [simulatedQueueCount, setSimulatedQueueCount] = useState(1);

  const handleReviewAction = (action: 'APPROVED' | 'FLAGGED' | 'DENIED') => {
    setHitlResolution(action);
    setHitlResolved(true);
    setShowReviewModal(false);
    setSimulatedQueueCount(0);

    const timestamp = new Date().toTimeString().split(' ')[0];
    let scoreDelta = 0;
    let logMessage = '';

    if (action === 'APPROVED') {
      scoreDelta = 0.4;
      logMessage = `[${timestamp}] ARCHITECT_DECISION: Force Approved return RTN-8821. Releasing shipping label.`;
    } else if (action === 'FLAGGED') {
      scoreDelta = -1.2;
      logMessage = `[${timestamp}] ARCHITECT_DECISION: Flagged and escalated return RTN-8821 to forensic team.`;
    } else {
      scoreDelta = 1.5;
      logMessage = `[${timestamp}] ARCHITECT_DECISION: Denied return RTN-8821 due to wardrobing signature mismatch.`;
    }

    setComplianceScore(prev => Math.min(100, parseFloat((prev + scoreDelta).toFixed(1))));
    setLogs(prev => [...prev, logMessage, `[${timestamp}] PIPELINE_STATUS: Automated loop finalized successfully.`]);
  };

  const handleResetLoop = () => {
    setHitlResolved(false);
    setHitlResolution(null);
    setSimulatedQueueCount(1);
    setLogs(prev => [
      ...prev,
      `[${new Date().toTimeString().split(' ')[0]}] SYSTEM_RESET: Re-instating simulation data loops...`
    ]);
  };

  return (
    <div className="space-y-xl" id="trace-tab-container">
      {/* Page Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-md">
        <div>
          <div className="flex items-center gap-sm mb-1">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            <span className="font-headline text-xs font-semibold text-primary tracking-widest uppercase">Live Process Monitor</span>
          </div>
          <h2 className="font-headline text-headline-xl text-[#e1e2ec]">Autonomous Workflow Loop</h2>
        </div>
        <div className="flex gap-sm">
          <button 
            onClick={() => setShowLogs(true)}
            className="px-4 py-2.5 rounded-xl bg-surface-container-highest border border-outline-variant text-on-surface-variant font-headline text-xs font-semibold flex items-center gap-1.5 hover:bg-surface-bright hover:text-white transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg">history</span>
            View Logs
          </button>
          <button 
            onClick={handleResetLoop}
            className="px-4 py-2.5 rounded-xl bg-primary text-on-primary font-headline text-xs font-semibold flex items-center gap-1.5 hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-lg shadow-primary/10"
          >
            <span className="material-symbols-outlined text-lg">sync</span>
            Reset Simulation
          </button>
        </div>
      </div>

      {/* Main Workflow Content (Vertical Timeline Layout + Sidebar) */}
      <div className="grid grid-cols-12 gap-gutter">
        {/* Timeline (8 columns) */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-0 relative">
          {/* Vertical Line (The Path) */}
          <div className="absolute left-[39px] top-[40px] bottom-[40px] w-0.5 connecting-line z-0"></div>

          {/* Step 1: Perceive */}
          <div className="relative z-10 flex gap-lg pb-xl group">
            <div className="flex-shrink-0 w-20 h-20 rounded-full glass-panel border-2 border-primary flex items-center justify-center node-glow bg-surface-container-low transition-all duration-300 group-hover:scale-105 shadow-lg">
              <span className="material-symbols-outlined text-primary text-[32px]">psychology</span>
            </div>
            <div className="flex-grow pt-2">
              <div className="glass-panel p-md rounded-xl border-l-4 border-l-primary border border-outline-variant/15">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-headline text-lg font-bold text-primary">Perceive</h3>
                  <span className="bg-primary/10 text-primary text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-primary/20">Phase 01</span>
                </div>
                <p className="text-on-surface-variant font-sans text-body-sm leading-relaxed mb-3">
                  Identify and ingest incoming return requests. Extracting intent from multi-channel inputs (email, customer portal, legacy ERP, and partner APIs).
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <span className="px-2 py-0.5 bg-surface-container-highest rounded text-[11px] font-mono border border-outline-variant/30 text-on-surface">
                    request_id: RTN-8821
                  </span>
                  <span className="px-2 py-0.5 bg-surface-container-highest rounded text-[11px] font-mono border border-outline-variant/30 text-on-surface">
                    source: webhook_aws
                  </span>
                  <span className="px-2 py-0.5 bg-surface-container-highest rounded text-[11px] font-mono border border-outline-variant/30 text-on-surface">
                    status: ingested
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Plan */}
          <div className="relative z-10 flex gap-lg pb-xl group">
            <div className="flex-shrink-0 w-20 h-20 rounded-full glass-panel border-2 border-outline flex items-center justify-center bg-surface-container-low transition-all duration-300 group-hover:scale-105 shadow-md">
              <span className="material-symbols-outlined text-on-surface-variant text-[32px]">account_tree</span>
            </div>
            <div className="flex-grow pt-2">
              <div className="glass-panel p-md rounded-xl border-l-4 border-l-outline border border-outline-variant/15">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-headline text-lg font-bold text-on-surface">Plan</h3>
                  <span className="bg-outline/10 text-on-surface-variant text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-outline-variant/20">Phase 02</span>
                </div>
                <p className="text-on-surface-variant font-sans text-body-sm leading-relaxed mb-3">
                  Verify return policies against user tiers, historic complaints, and dynamic categories. Calculating optimal routing targets based on local warehouse storage.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="p-2.5 bg-surface-container rounded-lg border border-outline-variant/10">
                    <div className="text-[10px] text-on-surface-variant uppercase font-semibold">Policy Match</div>
                    <div className="text-xs font-mono text-on-surface font-semibold mt-0.5">Standard_30_Day (VIP)</div>
                  </div>
                  <div className="p-2.5 bg-surface-container rounded-lg border border-outline-variant/10">
                    <div className="text-[10px] text-on-surface-variant uppercase font-semibold">Logistics Route</div>
                    <div className="text-xs font-mono text-on-surface font-semibold mt-0.5">Carrier_B_Express</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3: Execute (Critical / HitL Trigger) */}
          <div className="relative z-10 flex gap-lg pb-xl group">
            <div className={`flex-shrink-0 w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-105 shadow-lg ${hitlResolved ? 'bg-emerald-500/10 border-2 border-emerald-500 text-emerald-400' : 'bg-error-container/20 border-2 border-error text-error animate-pulse-subtle'}`}>
              <span className="material-symbols-outlined text-[32px]">{hitlResolved ? 'check_circle' : 'bolt'}</span>
            </div>
            <div className="flex-grow pt-2">
              <div className={`glass-panel p-md rounded-xl border relative overflow-hidden transition-colors duration-300 ${hitlResolved ? 'border-l-4 border-l-emerald-500 border-outline-variant/15' : 'border-l-4 border-l-error border-outline-variant/20'}`}>
                {/* Background alert glow */}
                <div className={`absolute top-0 right-0 w-32 h-full bg-gradient-to-l pointer-events-none ${hitlResolved ? 'from-emerald-500/5' : 'from-error/5'}`}></div>
                
                <div className="flex justify-between items-start mb-1">
                  <div className="flex items-center gap-2">
                    <h3 className={`font-headline text-lg font-bold ${hitlResolved ? 'text-emerald-400' : 'text-error'}`}>Execute</h3>
                    {!hitlResolved && (
                      <div className="flex items-center gap-1 px-2 py-0.5 bg-error text-on-error rounded text-[10px] font-bold animate-pulse">
                        <span className="material-symbols-outlined text-xs">warning</span>
                        ATTENTION
                      </div>
                    )}
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${hitlResolved ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-error/10 text-error border border-error/20'}`}>Phase 03</span>
                </div>
                
                <p className="text-on-surface-variant font-sans text-body-sm leading-relaxed mb-3">
                  {hitlResolved 
                    ? `Verification resolved by Human architect. Disposition: [${hitlResolution}]. Shipping protocols initialized.`
                    : "Generating labels and screening for fraud signatures. AI flagged abnormal item frequency pattern mismatch."}
                </p>

                {/* HITL Trigger Alert Box */}
                {!hitlResolved ? (
                  <div className="bg-error-container/10 border border-error/30 rounded-xl p-md mb-2 shadow-inner">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded bg-error/20 text-error flex items-center justify-center">
                          <span className="material-symbols-outlined">person_search</span>
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-on-surface font-headline">Human-in-the-Loop Required</div>
                          <div className="text-[11px] text-error font-bold mt-0.5">Confidence: 74.2% (&lt; 85% Threshold)</div>
                        </div>
                      </div>
                      <button 
                        id="review-now-btn"
                        onClick={() => setShowReviewModal(true)}
                        className="px-4 py-2 bg-error hover:brightness-110 text-on-error rounded-lg font-headline text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-lg shadow-error/20 self-start sm:self-auto"
                      >
                        Review Now
                      </button>
                    </div>
                    <div className="h-1.5 w-full bg-surface-container-highest rounded-full overflow-hidden mt-3">
                      <div className="h-full bg-error rounded-full transition-all duration-500" style={{ width: '74.2%' }}></div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-md mb-2">
                    <div className="flex items-center gap-2.5 text-emerald-400">
                      <span className="material-symbols-outlined text-xl">verified_user</span>
                      <div className="text-xs font-semibold">Verified Disposition: <span className="underline font-mono">{hitlResolution}</span></div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-1.5 mt-2">
                  <span className="material-symbols-outlined text-on-surface-variant text-base">info</span>
                  <span className="text-[11px] text-on-surface-variant italic">
                    {hitlResolved 
                      ? "Execution pipeline successfully resumed."
                      : "Automated execution paused. Awaiting architect verification for Fraud Score > 0.7"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 4: Evaluate */}
          <div className="relative z-10 flex gap-lg group">
            <div className={`flex-shrink-0 w-20 h-20 rounded-full glass-panel border-2 flex items-center justify-center bg-surface-container-low transition-all duration-300 group-hover:scale-105 shadow-md ${hitlResolved ? 'border-tertiary text-tertiary' : 'border-outline-variant/30 text-on-surface-variant'}`}>
              <span className="material-symbols-outlined text-[32px]">{hitlResolved ? 'task_alt' : 'fact_check'}</span>
            </div>
            <div className="flex-grow pt-2">
              <div className={`glass-panel p-md rounded-xl border border-outline-variant/15 transition-colors ${hitlResolved ? 'border-l-4 border-l-tertiary' : 'border-l-4 border-l-outline-variant'}`}>
                <div className="flex justify-between items-start mb-1">
                  <h3 className={`font-headline text-lg font-bold ${hitlResolved ? 'text-tertiary' : 'text-on-surface-variant'}`}>Evaluate</h3>
                  <span className="bg-outline/10 text-on-surface-variant text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-outline-variant/20">Phase 04</span>
                </div>
                <p className="text-on-surface-variant font-sans text-body-sm leading-relaxed mb-3">
                  Final transaction reconciliation and automated balance update. Sync downstream ERP nodes (Shopify/Stripe APIs) and dispatch customer alerts.
                </p>
                <div className="flex items-center justify-between p-2.5 bg-tertiary/5 rounded-lg border border-tertiary/10 font-mono text-[10px]">
                  <div className="flex items-center gap-2">
                    <span className={`material-symbols-outlined text-base ${hitlResolved ? 'text-emerald-400' : 'text-tertiary animate-pulse'}`}>{hitlResolved ? 'check_circle' : 'hourglass'}</span>
                    <span className="text-on-surface">
                      {hitlResolved ? 'Verification complete. Dispatched sync updates.' : 'Awaiting phase 3 resolution trigger'}
                    </span>
                  </div>
                  <span className="text-tertiary font-bold">Queue: {simulatedQueueCount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar (4 columns) */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-gutter">
          {/* Compliance Guardrail */}
          <div className="glass-panel rounded-xl overflow-hidden relative border border-outline-variant/15 shadow-lg">
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-tertiary to-error"></div>
            <div className="p-lg">
              <h4 className="font-headline text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mb-3">Compliance Score</h4>
              <div className="flex items-end gap-1 mb-2">
                <span className="text-5xl font-bold text-primary font-headline leading-none">{complianceScore}</span>
                <span className="text-on-surface-variant font-headline text-sm pb-1 font-semibold">/ 100</span>
              </div>
              <p className="text-xs text-on-surface-variant leading-relaxed mb-4">
                Current workflow loop maintains high compliance scores. Flagging anomalies is required for outlier safety handling.
              </p>
              
              <div className="space-y-3 pt-2">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-semibold">
                    <span className="text-on-surface-variant">Data Privacy</span>
                    <span className="text-primary font-bold">Optimal (98%)</span>
                  </div>
                  <div className="h-1 w-full bg-surface-container-highest rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '98%' }}></div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-semibold">
                    <span className="text-on-surface-variant">Policy Accuracy</span>
                    <span className="text-tertiary font-bold">Stable (91%)</span>
                  </div>
                  <div className="h-1 w-full bg-surface-container-highest rounded-full overflow-hidden">
                    <div className="h-full bg-tertiary rounded-full" style={{ width: '91%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Process Heatmap / Compliance score Line Chart */}
          <div className="glass-panel rounded-xl p-lg h-60 relative flex flex-col justify-between overflow-hidden border border-outline-variant/15">
            <div className="flex justify-between items-center mb-1">
              <h4 className="font-headline text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">30-Day Score Trend</h4>
              <span className="text-[10px] text-indigo-400 font-mono font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#818cf8] animate-pulse" />
                Live Trace
              </span>
            </div>
            <div className="flex-grow w-full h-full min-h-0 pt-2">
              <ComplianceLineChart complianceScore={complianceScore} />
            </div>
          </div>

          {/* Node Status Summary */}
          <div className="glass-panel rounded-xl p-lg border border-outline-variant/15">
            <h4 className="font-headline text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mb-3">System Health</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-md">
                <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center border border-outline-variant/30 text-primary">
                  <span className="material-symbols-outlined text-lg">memory</span>
                </div>
                <div className="flex-grow">
                  <div className="text-xs font-semibold text-on-surface font-headline">Compute Cluster</div>
                  <div className="text-[10px] text-on-surface-variant font-mono mt-0.5">Load: 42% | Temp: 58°C</div>
                </div>
              </li>
              <li className="flex items-center gap-md">
                <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center border border-outline-variant/30 text-tertiary">
                  <span className="material-symbols-outlined text-lg">storage</span>
                </div>
                <div className="flex-grow">
                  <div className="text-xs font-semibold text-on-surface font-headline">Neural Storage</div>
                  <div className="text-[10px] text-on-surface-variant font-mono mt-0.5">Available: 4.8 TB / 10 TB</div>
                </div>
              </li>
              <li className="flex items-center gap-md">
                <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center border border-outline-variant/30 text-error">
                  <span className="material-symbols-outlined text-lg animate-pulse">hub</span>
                </div>
                <div className="flex-grow">
                  <div className="text-xs font-semibold text-on-surface font-headline">Interconnects</div>
                  <div className="text-[10px] text-error font-mono font-bold mt-0.5">1 Node Throttled</div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Human Adjudication Modal */}
      <AnimatePresence>
        {showReviewModal && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-lg rounded-2xl border border-outline-variant/30 overflow-hidden shadow-2xl bg-surface-container-low"
            >
              <div className="bg-error-container/20 px-lg py-md border-b border-error/30 flex justify-between items-center">
                <div className="flex items-center gap-2 text-error">
                  <span className="material-symbols-outlined">gpp_maybe</span>
                  <h3 className="font-headline text-lg font-bold">Human Adjudication Desk</h3>
                </div>
                <button 
                  onClick={() => setShowReviewModal(false)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg space-y-md">
                <div className="bg-surface-container p-md rounded-xl space-y-2 border border-outline-variant/15">
                  <div className="text-xs font-semibold text-primary uppercase font-headline tracking-wider">Transaction File: RTN-8821</div>
                  <div className="grid grid-cols-2 gap-sm text-xs font-mono pt-1">
                    <div>
                      <span className="text-on-surface-variant">Customer Name:</span>
                      <span className="text-on-surface block font-semibold">Sarah J. Jenkins</span>
                    </div>
                    <div>
                      <span className="text-on-surface-variant">Account Age:</span>
                      <span className="text-on-surface block font-semibold">3.4 Years (Gold VIP)</span>
                    </div>
                    <div>
                      <span className="text-on-surface-variant">SKU Claimed:</span>
                      <span className="text-on-surface block font-semibold">Delicate Silk Blazer</span>
                    </div>
                    <div>
                      <span className="text-on-surface-variant">SKU Price:</span>
                      <span className="text-tertiary block font-semibold">$340.00</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-on-surface font-headline block">Flagged Risk Mismatches</span>
                  <div className="p-3 bg-error-container/10 border border-error/20 rounded-lg text-xs leading-relaxed text-on-error-container space-y-2">
                    <p className="font-semibold">
                      Anomalous Pattern Detected: Return Rate is 42% (Peer benchmark is 12.5%).
                    </p>
                    <p className="text-[11px] text-on-surface-variant italic">
                      Linguistic audit checks indicate positive satisfaction in feedback form logs, conflicting with the prompt resolution requested.
                    </p>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="text-xs font-bold text-on-surface font-headline block mb-2">Issue Final Disposition</span>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      onClick={() => handleReviewAction('APPROVED')}
                      className="px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-headline font-semibold text-center cursor-pointer transition-colors"
                    >
                      APPROVE RETURN
                    </button>
                    <button 
                      onClick={() => handleReviewAction('FLAGGED')}
                      className="px-3 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-headline font-semibold text-center cursor-pointer transition-colors"
                    >
                      FLAG &amp; AUDIT
                    </button>
                    <button 
                      onClick={() => handleReviewAction('DENIED')}
                      className="px-3 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-headline font-semibold text-center cursor-pointer transition-colors"
                    >
                      DENY CLAIM
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-surface-container-high/50 px-lg py-3.5 border-t border-outline-variant/20 text-[11px] text-on-surface-variant italic font-mono flex justify-between items-center">
                <span>Subject to SLA tracking limit of 15m.</span>
                <span>Console Session: Secure</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Slide-out Terminal Logs Drawer */}
      <AnimatePresence>
        {showLogs && (
          <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-[#020205]/95 backdrop-blur-md border-l border-white/10 z-50 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">history</span>
                  <h3 className="font-headline text-base font-bold text-on-surface">Console Log Stream</h3>
                </div>
                <button 
                  onClick={() => setShowLogs(false)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg font-mono text-xs space-y-2 max-h-[calc(100vh-120px)] overflow-y-auto">
                {logs.map((log, index) => (
                  <div key={index} className={`pb-1.5 border-b border-outline-variant/5 ${log.includes('ARCHITECT') ? 'text-primary font-bold' : log.includes('SYSTEM') ? 'text-tertiary' : 'text-on-surface-variant'}`}>
                    {log}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-surface-container px-lg py-md border-t border-outline-variant/20 flex justify-between items-center">
              <span className="text-[11px] font-mono text-on-surface-variant">Logs persisted in session</span>
              <button 
                onClick={() => setLogs([])}
                className="text-xs text-error hover:underline"
              >
                Clear Stream
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
